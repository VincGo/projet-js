var Station = {
    init:function(data) {
        this.adresse = data.fields.address;
        this.lat = data.fields.position[0];
        this.lng = data.fields.position[1];
        this.place = data.fields.available_bike_stands;
        this.dispo = data.fields.available_bikes;
        this.paiement = data.fields.banking;
        this.status = data.fields.status;
    },
//affiche information station vélo
    detailStation: function () {
        if(this.status == "CLOSED" || this.dispo == 0){
            $('#indispo').show();
            $('#clear').hide();  
            $('input').hide();
            $('section').css("visibility", "visible");
            $('#adress').text(this.adresse);
            $('#nbmax').text(this.place);
            $('#dispo').text(this.dispo)
        } 
        else {
            $('#indispo').hide();
            $('section').css("visibility", "visible");
            $('#clear').show();
            $('input').show();
            $('#adress').text(this.adresse);
            $('#nbmax').text(this.place);
            $('#dispo').text(this.dispo);
        }
    },
};






